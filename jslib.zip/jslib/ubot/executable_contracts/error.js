function doError() {
    throw new Error("Simple test error message.");
}