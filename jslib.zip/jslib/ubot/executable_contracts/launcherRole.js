function method_for_launcher1() {
    return 1;
}

function method_for_launcher2() {
    return 2;
}

function method_for_any() {
    return 3;
}