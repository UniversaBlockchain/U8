alter table config add unique (node_number);
alter table config add unique (node_name);
alter table config add unique (public_key);