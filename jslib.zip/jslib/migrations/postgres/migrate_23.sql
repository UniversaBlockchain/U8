create index ix_keeping_items_hash on keeping_items(hash);
create index ix_keeping_items_origin on keeping_items(origin);