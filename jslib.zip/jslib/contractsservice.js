/*
 * Copyright (c) 2019-present Sergey Chernov, iCodici S.n.C, All Rights Reserved.
 */

/**
 * @module contractsservice
 */
import {HashId} from 'crypto'
import {randomBytes} from 'tools'

const BossBiMapper = require("bossbimapper").BossBiMapper;
const Contract = require("contract").Contract;
const TransactionPack = require("transactionpack").TransactionPack;
const Parcel = require("parcel").Parcel;
const roles = require('roles');
const perms = require('permissions');
const BigDecimal  = require("big").Big;
const Constraint = require('constraint').Constraint;
const ex = require("exceptions");
const io = require("io");
const SlotContract = require("services/slotContract").SlotContract;
const UnsContract = require("services/unsContract").UnsContract;
const UnsName = require("services/unsName").UnsName;
const UnsRecord = require("services/unsRecord").UnsRecord;
const FollowerContract = require("services/followerContract").FollowerContract;

/**
 * Implementing revoking procedure.
 * Service create temp contract with given contract in revoking items and return it.
 * That temp contract should be send to Universa and given contract will be revoked.
 *
 * @param {Contract} c - Contract should revoked be.
 * @param {crypto.PrivateKey} keys - Keys from owner of revoking contract.
 * @return {Contract} working contract that should be register in the Universa to finish procedure.
 */
async function createRevocation(c, ...keys) {

    let tc = new Contract();

    // by default, transactions expire in 30 days
    tc.definition.expiresAt = new Date(tc.definition.createdAt);
    tc.definition.expiresAt.setDate(tc.definition.expiresAt.getDate() + 30);

    tc.registerRole(new roles.SimpleRole("issuer", keys));
    tc.registerRole(new roles.RoleLink("owner", "issuer"));
    tc.registerRole(new roles.RoleLink("creator", "issuer"));

    tc.definition.data.actions = [{action : "remove", id : c.id}];
    tc.revokingItems.add(c);

    for (let key of keys)
        tc.keysToSignWith.add(key);

    await tc.seal(true);

    return tc;
}

/**
 * Implementing split procedure for token-type contracts.
 * Service create new revision of given contract, split it to a pair of contracts with split amount.
 * Given contract should have splitjoin permission for given keys.
 *
 * @param {Contract} c - Contract should split be.
 * @param {number | string | BigDecimal} amount - Value that should be split from given contract.
 * @param {String} fieldName - Name of field that should be split.
 * @param {Iterable<crypto.PrivateKey>} keys - Keys from owner of splitting contract.
 * @param {boolean} andSetCreator - If true set owners as creator in both contracts.
 * @return {Contract} working contract that should be register in the Universa to finish procedure.
 */
async function createSplit(c, amount, fieldName, keys, andSetCreator = false) {
    let splitFrom = await c.createRevision();
    let splitTo = await splitFrom.splitValue(fieldName, amount);

    for (let key of keys)
        splitFrom.keysToSignWith.add(key);

    if (andSetCreator) {
        splitTo.registerRole(new roles.RoleLink("creator", "owner"));
        splitFrom.registerRole(new roles.RoleLink("creator", "owner"));
    }

    await splitTo.seal(true);
    await splitFrom.seal(true);

    return splitFrom;
}

/**
 * Implementing join procedure.
 * Service create new revision of first contract, update amount field with sum of amount fields in the both contracts
 * and put second contract in revoking items of created new revision.
 * Given contract should have splitjoin permission for given keys.
 *
 * @param {Contract} contract1 - Contract should be join to.
 * @param {Contract} contract2 - Contract should be join.
 * @param {String} fieldName - Name of field that should be join by.
 * @param {Iterable<crypto.PrivateKey>} keys - Keys from owner of both contracts.
 * @return {Contract} working contract that should be register in the Universa to finish procedure.
 */
async function createJoin(contract1, contract2, fieldName, keys) {
    let joinTo = await contract1.createRevision();

    if (contract1.state.data[fieldName] == null || contract2.state.data[fieldName] == null)
        throw new ex.IllegalArgumentError("createJoin: not found field state.data." + fieldName);

    let sum = new BigDecimal(contract1.state.data[fieldName]).add(new BigDecimal(contract2.state.data[fieldName]));
    joinTo.state.data[fieldName] = sum.toFixed();

    for (let key of keys)
        joinTo.keysToSignWith.add(key);

    joinTo.revokingItems.add(contract2);

    await joinTo.seal(true);

    return joinTo;
}

/**
 * Implementing join procedure.
 * Service create new revision of first contract, update amount field with sum of amount fields in the both contracts
 * and put second contract in revoking items of created new revision.
 * Given contract should have splitjoin permission for given keys.
 *
 * @param {Iterable<Contract>} contractsToJoin - One or more contracts to join into main contract.
 * @param {Array<number | string | BigDecimal>} amountsToSplit - Array contains one or more amounts to split from main contract.
 * @param {Array<crypto.KeyAddress>} addressesToSplit - Addresses the ownership of splitted parts will be transferred to.
 * @param {Iterable<crypto.PrivateKey> | null} ownerKeys - Owner keys of joined contracts.
 * @param {string} fieldName - Name of field that should be join by.
 * @return {Array<Contract>} list of contracts containing main contract followed by splitted parts.
 */
async function createSplitJoin(contractsToJoin, amountsToSplit, addressesToSplit, ownerKeys, fieldName) {
    let contract = null;
    let sum = new BigDecimal(0);
    for (let c of contractsToJoin) {
        if (contract == null) {
            contract = c;
            contract = await contract.createRevision(ownerKeys);
        } else
            contract.revokingItems.add(c);

        if (c.state.data[fieldName] == null)
            throw new ex.IllegalArgumentError("createSplitJoin: not found field state.data." + fieldName);

        sum = sum.add(new BigDecimal(c.state.data[fieldName]));
    }

    let parts = [];
    if (amountsToSplit != null && amountsToSplit.length > 0 && addressesToSplit != null && addressesToSplit.length > 0) {
        parts = await contract.split(amountsToSplit.length);
        for (let i = 0; i < parts.length; i++) {
            sum = sum.sub(new BigDecimal(amountsToSplit[i]));
            parts[i].registerRole(new roles.SimpleRole("owner", addressesToSplit[i]));
            parts[i].state.data[fieldName] = new BigDecimal(amountsToSplit[i]).toFixed();

            await parts[i].seal();
        }
    }

    contract.state.data[fieldName] = sum.toFixed();
    await contract.seal(true);

    return [contract].concat(parts);
}

/**
 * First step of swap procedure. Calls from swapper1 part.
 *
 * Get lists of contracts.
 *
 * Service create new revisions of existing contracts, change owners,
 * added transactional sections with references to each other with asks two signs of swappers
 * and sign contract that was own for calling part.
 *
 * Swap procedure consist from three steps:
 * (1) prepare contracts with creating transactional section on the first swapper site;
 * (2) sign main contract on the first swapper site;
 * (3) sign main contract on the second swapper site.
 *
 * @param {Iterable<Contract>} contracts1 - List of own for calling part (swapper1 owned), existing or new revision of contract.
 * @param {Iterable<Contract>} contracts2 - List of foreign for calling part (swapper2 owned), existing or new revision contract.
 * @param {Iterable<crypto.PrivateKey>} fromKeys - Own for calling part (swapper1 keys) private keys.
 * @param {Iterable<crypto.PublicKey>} toKeys - Foreign for calling part (swapper2 keys) public keys.
 * @param {boolean} createNewRevision - If true - create new revision of given contracts. If false - use them as new revisions.
 * @return {Contract} swap contract including new revisions of old contracts swapping between;
 * should be send to partner (swapper2) and he should go to step (2) of the swap procedure.
 */
async function startSwap(contracts1, contracts2, fromKeys, toKeys, createNewRevision) {

    // first of all we creating main swap contract which will include new revisions of contract for swap
    // you can think about this contract as about transaction
    let swapContract = new Contract();

    // by default, transactions expire in 30 days
    swapContract.definition.expiresAt = new Date(swapContract.definition.createdAt);
    swapContract.definition.expiresAt.setDate(swapContract.definition.expiresAt.getDate() + 30);

    swapContract.registerRole(new roles.SimpleRole("issuer", fromKeys));
    swapContract.registerRole(new roles.RoleLink("owner", "issuer"));
    swapContract.registerRole(new roles.RoleLink("creator", "issuer"));

    // now we will prepare new revisions of contracts

    // create new revisions of contracts and create transactional sections in it
    let newContracts1 = [];
    for (let c of contracts1) {
        let nc = createNewRevision ? await c.createRevision(fromKeys) : c;
        nc.createTransactionalSection();
        nc.transactional.id = HashId.of(randomBytes(64)).base64;

        newContracts1.push(nc);
    }

    let newContracts2 = [];
    for (let c of contracts2) {
        let nc = createNewRevision ? await c.createRevision() : c;
        if (createNewRevision) {
            // set new creator
            let addresses = Array.from(toKeys).map(k => k.longAddress);
            nc.registerRole(new roles.SimpleRole("creator", addresses));
        }

        nc.createTransactionalSection();
        nc.transactional.id = HashId.of(randomBytes(64)).base64;

        newContracts2.push(nc);
    }

    // prepare roles for references
    // it should new owners and old creators in new revisions of contracts
    let ownerFrom = new roles.SimpleRole("owner", fromKeys);
    let creatorFrom = new roles.SimpleRole("creator", fromKeys);

    let ownerTo = new roles.SimpleRole("owner", toKeys);
    let creatorTo = new roles.SimpleRole("creator", toKeys);

    // create references for contracts that point to each other and asks correct signs
    // and add this references to existing transactional section
    newContracts1.forEach(nc1 => newContracts2.forEach(nc2 => {
        let constr = new Constraint(nc1);
        constr.transactional_id = nc2.transactional.id;
        constr.type = Constraint.TYPE_TRANSACTIONAL;
        constr.signed_by.push(ownerFrom);
        constr.signed_by.push(creatorTo);
        nc1.addConstraint(constr);
    }));

    newContracts2.forEach(nc2 => newContracts1.forEach(nc1 => {
        let constr = new Constraint(nc2);
        constr.transactional_id = nc1.transactional.id;
        constr.type = Constraint.TYPE_TRANSACTIONAL;
        constr.signed_by.push(ownerTo);
        constr.signed_by.push(creatorFrom);
        nc2.addConstraint(constr);
    }));

    // swap owners in this contracts and add created new revisions to main swap contract
    await Promise.all(newContracts1.map(async(nc) => {
        nc.registerRole(new roles.SimpleRole("owner", toKeys));
        await nc.seal();
        swapContract.newItems.add(nc);
    }));

    await Promise.all(newContracts2.map(async(nc) => {
        nc.registerRole(new roles.SimpleRole("owner", fromKeys));
        await nc.seal();
        swapContract.newItems.add(nc);
    }));

    await swapContract.seal(true);

    return swapContract;
}

/**
 * Creates a contract with two signatures.
 *
 * The service creates a contract which asks two signatures.
 * It can not be registered without both parts of deal, so it is make sure both parts that they agreed with contract.
 * Service creates a contract that should be send to partner,
 * then partner should sign it and return back for final sign from calling part.
 *
 * @param {Contract} baseContract - Base contract.
 * @param {Iterable<crypto.PrivateKey>} fromKeys - Own private keys.
 * @param {Iterable<crypto.PublicKey>} toKeys - Foreign public keys.
 * @param {boolean} createNewRevision - Create new revision if true.
 * @return {Contract} contract with two signatures that should be send from first part to partner.
 */
async function createTwoSignedContract(baseContract, fromKeys, toKeys, createNewRevision) {

    let twoSignContract;

    if (createNewRevision) {
        twoSignContract = await baseContract.createRevision(fromKeys);
        twoSignContract.keysToSignWith.clear();
    } else
        twoSignContract = await baseContract.copy();

    let creatorFrom = new roles.SimpleRole("creator", fromKeys);
    let ownerTo = new roles.SimpleRole("owner", toKeys);

    twoSignContract.createTransactionalSection();
    twoSignContract.transactional.id = HashId.of(randomBytes(64)).base64;

    let constraint = new Constraint(twoSignContract);
    constraint.transactional_id = twoSignContract.transactional.id;
    constraint.type = Constraint.TYPE_TRANSACTIONAL;
    constraint.signed_by.push(creatorFrom);
    constraint.signed_by.push(ownerTo);
    twoSignContract.addConstraint(constraint);

    twoSignContract.registerRole(new roles.SimpleRole("owner", toKeys));

    await twoSignContract.seal(true);

    return twoSignContract;
}

/**
 * Creates a token contract for given keys with given currency code,name,description.
 * The service creates a simple token contract with issuer, creator and owner roles;
 * with change_owner permission for owner, revoke permissions for owner and issuer and split_join permission for owner.
 * Split_join permission has by default following params: "minValue" for min_value and min_unit, "amount" for field_name,
 * "state.origin" for join_match_fields.
 * By default expires at time is set to 60 months from now.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {number | string | BigDecimal} amount - Maximum token number.
 * @param {number | string | BigDecimal} minValue - Minimum token value.
 * @param {string} currency - Currency code.
 * @param {string} name - Currency name.
 * @param {string} description  - Currency description.
 * @return {Contract} signed and sealed contract, ready for register.
 */
async function createTokenContract(issuerKeys, ownerKeys, amount, minValue = "0.01", currency = "DT",
                                   name = "Default token name", description = "Default token description") {

    let tokenContract = new Contract();

    tokenContract.definition.expiresAt = new Date(tokenContract.definition.createdAt);
    tokenContract.definition.expiresAt.setMonth(tokenContract.definition.expiresAt.getMonth() + 60);

    tokenContract.definition.data = {
        currency: currency,
        short_currency: currency,
        name: name,
        description: description
    };

    tokenContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    tokenContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    tokenContract.registerRole(new roles.RoleLink("creator", "issuer"));

    tokenContract.state.data.amount = new BigDecimal(amount).toFixed();

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = tokenContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = tokenContract;

    tokenContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    let params = {
        min_value: new BigDecimal(minValue).toFixed(),
        min_unit: new BigDecimal(minValue).toFixed(),
        field_name: "amount",
        join_match_fields: ["state.origin"]
    };

    tokenContract.definition.addPermission(new perms.SplitJoinPermission(ownerLink, params));

    tokenContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    tokenContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    await tokenContract.seal(true);
    await tokenContract.addSignatureToSeal(issuerKeys);

    return tokenContract;
}

/**
 * Creates a mintable token contract for given keys with given currency code,name,description.
 *
 * The service creates a mintable token contract with issuer, creator and owner roles;
 * with change_owner permission for owner, revoke permissions for owner and issuer and split_join permission for owner.
 * Split_join permission has  following params: "minValue" for min_value and min_unit, "amount" for field_name,
 * ["definition.data.currency", "definition.issuer"] for join_match_fields.
 * By default expires at time is set to 60 months from now.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {number | string | BigDecimal} amount - Maximum token number.
 * @param {number | string | BigDecimal} minValue - Minimum token value.
 * @param {string} currency - Currency code.
 * @param {string} name - Currency name.
 * @param {string} description  - Currency description.
 * @return {Contract} signed and sealed contract, ready for register.
 */
async function createMintableTokenContract(issuerKeys, ownerKeys, amount, minValue = "0.01", currency = "DT",
                                           name = "Default token name", description = "Default token description") {

    let tokenContract = new Contract();

    tokenContract.definition.expiresAt = new Date(tokenContract.definition.createdAt);
    tokenContract.definition.expiresAt.setMonth(tokenContract.definition.expiresAt.getMonth() + 60);

    tokenContract.definition.data = {
        currency: currency,
        short_currency: currency,
        name: name,
        description: description
    };

    tokenContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    tokenContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    tokenContract.registerRole(new roles.RoleLink("creator", "issuer"));

    tokenContract.state.data.amount = new BigDecimal(amount).toFixed();

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = tokenContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = tokenContract;

    tokenContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    let params = {
        min_value: new BigDecimal(minValue).toFixed(),
        min_unit: new BigDecimal(minValue).toFixed(),
        field_name: "amount",
        join_match_fields: ["definition.data.currency", "definition.issuer"]
    };

    tokenContract.definition.addPermission(new perms.SplitJoinPermission(ownerLink, params));

    tokenContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    tokenContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    await tokenContract.seal(true);
    await tokenContract.addSignatureToSeal(issuerKeys);

    return tokenContract;
}

/**
 * Creates a share contract for given keys.
 * The service creates a simple share contract with issuer, creator and owner roles
 * with change_owner permission for owner, revoke permissions for owner and issuer and split_join permission for owner.
 * Split_join permission has by default following params: 1 for min_value, 1 for min_unit, "amount" for field_name,
 * "state.origin" for join_match_fields.
 * By default expires at time is set to 60 months from now.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {number | string | BigDecimal} amount - Maximum shares number.
 * @return {Contract} signed and sealed contract, ready for register.
 */
async function createShareContract(issuerKeys, ownerKeys, amount) {

    let shareContract = new Contract();

    shareContract.definition.expiresAt = new Date(shareContract.definition.createdAt);
    shareContract.definition.expiresAt.setMonth(shareContract.definition.expiresAt.getMonth() + 60);

    shareContract.definition.data = {
        name: "Default share name",
        currency_code: "DSH",
        currency_name: "Default share name",
        description: "Default share description."
    };

    shareContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    shareContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    shareContract.registerRole(new roles.RoleLink("creator", "issuer"));

    shareContract.state.data.amount = new BigDecimal(amount).toFixed();

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = shareContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = shareContract;

    shareContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    let params = {
        min_value: 1,
        min_unit: 1,
        field_name: "amount",
        join_match_fields: ["state.origin"]
    };

    shareContract.definition.addPermission(new perms.SplitJoinPermission(ownerLink, params));

    shareContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    shareContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    await shareContract.seal(true);
    await shareContract.addSignatureToSeal(issuerKeys);

    return shareContract;
}

/**
 * Creates a simple notary contract for given keys.
 *
 * The service creates a notary contract with issuer, creator and owner roles
 * with change_owner permission for owner and revoke permissions for owner and issuer.
 * Optionally, the service attach the data to notary contract and data file descriptions.
 * By default expires at time is set to 60 months from now.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {Array<string> | null} filePaths - Array with paths to data files.
 * @param {Array<string> | null} fileDescriptions - Array with data file descriptions.
 * @return {Contract} signed and sealed contract, ready for register.
 */
async function createNotaryContract(issuerKeys, ownerKeys, filePaths = null, fileDescriptions = null) {

    let notaryContract = new Contract();

    notaryContract.definition.expiresAt = new Date(notaryContract.definition.createdAt);
    notaryContract.definition.expiresAt.setMonth(notaryContract.definition.expiresAt.getMonth() + 60);

    notaryContract.definition.data = {
        name: "Default notary",
        description: "Default notary description.",
        template_name: "NOTARY_CONTRACT",
        holder_identifier: "default holder identifier"
    };

    notaryContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    notaryContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    notaryContract.registerRole(new roles.RoleLink("creator", "issuer"));

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = notaryContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = notaryContract;

    notaryContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    notaryContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    notaryContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    if (filePaths != null && filePaths.length > 0) {
        // attache files
        let data = notaryContract.definition.data;
        let files = {};

        for (let i = 0; i < filePaths.length; i++) {
            let buffer = await io.fileGetContentsAsBytes(filePaths[i]);

            let fileName = filePaths[i].replace(/^.*[\\\/]/, "");
            let line = fileName.replace(/\W/g, "_");

            let fileData = {
                file_name: fileName,
                __type: "file",
                hash_id: HashId.of(buffer)
            };

            if (fileDescriptions != null && fileDescriptions[i] != null && typeof fileDescriptions[i] === "string")
                fileData.file_description = fileDescriptions[i];
            else
                fileData.file_description = "";

            files[line] = fileData;
        }

        data.files = files;
    }

    await notaryContract.seal(true);
    await notaryContract.addSignatureToSeal(issuerKeys);

    return notaryContract;
}

/**
 * Check the data attached to the notary contract.
 *
 * @param {Contract} notaryContract - Notary-type contract.
 * @param {string} filePaths - Path to attached file or folder with files.
 * @return {boolean} result of checking the data attached to the notary contract.
 */
async function checkAttachNotaryContract(notaryContract, filePaths) {
    let files = notaryContract.definition.data.files;

    if (!await io.isAccessible(filePaths))
        throw new ex.IllegalArgumentError("Cannot access " + filePaths);

    let isDir = await io.isDir(filePaths);
    let isFile = await io.isFile(filePaths);
    let normalPath = filePaths;

    if (isDir && !filePaths.endsWith("/"))
        normalPath = filePaths + "/";

    if (isFile) {
        let buffer = await io.fileGetContentsAsBytes(normalPath);
        let fileHash = HashId.of(buffer);

        for (let key of Object.keys(files)) {
            let file = files[key];
            try {
                if (!normalPath.endsWith(file.file_name))
                    continue;

                let notaryHash = await BossBiMapper.getInstance().deserialize(file.hash_id);

                if (fileHash.equals(notaryHash))
                    return true;
            } catch (err) {}
        }

        return false;

    } else if (isDir) {
        let results = await Promise.all(Object.keys(files).map(async(key) => {
            let file = files[key];
            try {
                let filePath = normalPath;
                if (filePath.endsWith("/"))
                    filePath += file.file_name;
                else if (!filePath.endsWith(file.file_name))
                    return false;

                let buffer = await io.fileGetContentsAsBytes(filePath);

                let fileHash = HashId.of(buffer);
                let notaryHash = await BossBiMapper.getInstance().deserialize(file.hash_id);

                return fileHash.equals(notaryHash);
            } catch (err) {
                return false;
            }
        }));

        return results.every(res => res);

    } else
        throw new ex.IllegalArgumentError("Cannot access " + filePaths + ": need regular file or directory");
}

/**
 * Create and return ready {@link SlotContract} contract with need permissions and values. {@link SlotContract} is
 * used for control and for payment for store some contracts in the distributed store.
 * Default expiration is set to 5 years.
 *
 * Created {@link SlotContract} has <i>change_owner</i>, <i>revoke</i> and <i>modify_data</i> with special slot
 * fields permissions. Sets issuerKeys as issuer, ownerKeys as owner. Use {@link SlotContract#putTrackingContract(Contract)}
 * for putting contract should be add to storage.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {NodeInfoProvider} nodeInfoProvider - Provider receiving information from node.
 * @return {SlotContract} slot-contract, ready for register.
 */
async function createSlotContract(issuerKeys, ownerKeys, nodeInfoProvider) {

    let slotContract = new SlotContract();
    slotContract.nodeInfoProvider = nodeInfoProvider;

    slotContract.definition.expiresAt = new Date(slotContract.definition.createdAt);
    slotContract.definition.expiresAt.setMonth(slotContract.definition.expiresAt.getMonth() + 60);

    slotContract.definition.data = {
        name: "Default slot",
        description: "Default slot description."
    };

    slotContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    slotContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    slotContract.registerRole(new roles.RoleLink("creator", "issuer"));

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = slotContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = slotContract;

    slotContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    slotContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    slotContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    slotContract.addSlotSpecific();

    await slotContract.seal(true);
    await slotContract.addSignatureToSeal(issuerKeys);

    return slotContract;
}

function createSimpleUnsContract(issuerKeys, ownerKeys, nodeInfoProvider) {

    let unsContract = new UnsContract();
    unsContract.nodeInfoProvider = nodeInfoProvider;

    unsContract.definition.expiresAt = new Date(unsContract.definition.createdAt);
    unsContract.definition.expiresAt.setMonth(unsContract.definition.expiresAt.getMonth() + 60);

    unsContract.definition.data = {
        name: "Default UNS contract",
        description: "Default UNS contract description."
    };

    unsContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    unsContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    unsContract.registerRole(new roles.RoleLink("creator", "issuer"));

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = unsContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = unsContract;

    unsContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    unsContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    unsContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    unsContract.addUnsSpecific();

    return unsContract;
}

/**
 * Create and return ready {@link UnsContract} contract with need permissions and values. {@link UnsContract} is
 * used for control and for payment for register some names in the distributed store.
 * Default expiration is set to 5 years.
 *
 * Created {@link UnsContract} has <i>change_owner</i>, <i>revoke</i> and <i>modify_data</i> with special uns
 * fields permissions. Sets issuerKeys as issuer, ownerKeys as owner. Use {@link UnsContract#addUnsName(UnsName)}
 * for putting UNS name should be register.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {NodeInfoProvider} nodeInfoProvider - Provider receiving information from node.
 * @return {UnsContract} UNS-contract, ready for register.
 */
async function createUnsContract(issuerKeys, ownerKeys, nodeInfoProvider) {

    let unsContract = createSimpleUnsContract(issuerKeys, ownerKeys, nodeInfoProvider);

    await unsContract.seal(true);
    await unsContract.addSignatureToSeal(issuerKeys);

    return unsContract;
}

/**
 * Create and return ready {@link UnsContract} contract with need permissions and values. {@link UnsContract} is
 * used for control and for payment for register some names in the distributed store.
 * Default expiration is set to 5 years.
 *
 * Created {@link UnsContract} has <i>change_owner</i>, <i>revoke</i> and <i>modify_data</i> with special uns
 * fields permissions. Sets issuerKeys as issuer, ownerKeys as owner.
 * Also added UNS name for registration associated with contract (by origin).
 * Use {@link UnsContract#addUnsName(UnsName)} for putting additional UNS name should be register.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {NodeInfoProvider} nodeInfoProvider - Provider receiving information from node.
 * @param {string} name - Name for registration.
 * @param {string} description - Description associated with name for registration.
 * @param {string} URL - URL associated with name for registration.
 * @param {Contract} namedContract - Named contract.
 * @return {UnsContract} UNS-contract, ready for register.
 */
async function createUnsContractForRegisterContractName(issuerKeys, ownerKeys, nodeInfoProvider, name, description, URL, namedContract) {

    let unsContract = createSimpleUnsContract(issuerKeys, ownerKeys, nodeInfoProvider);

    if (namedContract.id == null)
        throw new ex.IllegalArgumentError("createUnsContractForRegisterContractName: namedContract not sealed.");

    let unsName = new UnsName(name, description, URL);
    let unsRecord = UnsRecord.fromOrigin(namedContract.id);
    unsName.addUnsRecord(unsRecord);
    unsContract.addUnsName(unsName);
    unsContract.addOriginContract(namedContract);

    await unsContract.seal(true);
    await unsContract.addSignatureToSeal(issuerKeys);

    return unsContract;
}

/**
 * Create and return ready {@link UnsContract} contract with need permissions and values. {@link UnsContract} is
 * used for control and for payment for register some names in the distributed store.
 * Default expiration is set to 5 years.
 *
 * Created {@link UnsContract} has <i>change_owner</i>, <i>revoke</i> and <i>modify_data</i> with special uns
 * fields permissions. Sets issuerKeys as issuer, ownerKeys as owner.
 * Also added uns name for registration associated with key (by addresses).
 * Use {@link UnsContract#addUnsName(UnsName)} for putting additional uns name should be register.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {NodeInfoProvider} nodeInfoProvider - Provider receiving information from node.
 * @param {string} name - Name for registration.
 * @param {string} description - Description associated with name for registration.
 * @param {string} URL - URL associated with name for registration.
 * @param {crypto.PrivateKey | crypto.PublicKey} namedKey - Named key.
 * @return {UnsContract} UNS-contract, ready for register.
 */
async function createUnsContractForRegisterKeyName(issuerKeys, ownerKeys, nodeInfoProvider, name, description, URL, namedKey) {

    let unsContract = createSimpleUnsContract(issuerKeys, ownerKeys, nodeInfoProvider);

    let unsName = new UnsName(name, description, URL);
    let unsRecord = UnsRecord.fromKey(namedKey instanceof crypto.PrivateKey ? namedKey.publicKey : namedKey);
    unsName.addUnsRecord(unsRecord);
    unsContract.addUnsName(unsName);

    await unsContract.seal(true);
    await unsContract.addSignatureToSeal(issuerKeys);

    return unsContract;
}

/**
 * Create and return ready {@link FollowerContract} contract with need permissions and values. {@link FollowerContract} is
 * used for control and for payment for follow new revisions from some contract chains by origin.
 * Default expiration is set to 5 years.
 *
 * Created {@link FollowerContract} has <i>change_owner</i>, <i>revoke</i> and <i>modify_data</i> with special follower
 * fields permissions. Sets issuerKeys as issuer, ownerKeys as owner. Use {@link FollowerContract#putTrackingOrigin(HashId, String, PublicKey)}
 * for putting follow chain by origin with callback URL and public key.
 *
 * @param {Iterable<crypto.PrivateKey>} issuerKeys - Issuer public keys.
 * @param {Iterable<crypto.PublicKey>} ownerKeys - Owner public keys.
 * @param {NodeInfoProvider} nodeInfoProvider - Provider receiving information from node.
 * @return {FollowerContract} follower-contract, ready for register.
 */
async function createFollowerContract(issuerKeys, ownerKeys, nodeInfoProvider) {

    let followerContract = new FollowerContract();
    followerContract.nodeInfoProvider = nodeInfoProvider;

    followerContract.definition.expiresAt = new Date(followerContract.definition.createdAt);
    followerContract.definition.expiresAt.setMonth(followerContract.definition.expiresAt.getMonth() + 60);

    followerContract.definition.data = {
        name: "Default follower",
        description: "Default follower description."
    };

    followerContract.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    followerContract.registerRole(new roles.SimpleRole("owner", ownerKeys));
    followerContract.registerRole(new roles.RoleLink("creator", "issuer"));

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = followerContract;
    let issuerLink = new roles.RoleLink("@issuer_link", "issuer");
    issuerLink.contract = followerContract;

    followerContract.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));

    followerContract.definition.addPermission(new perms.RevokePermission(ownerLink));
    followerContract.definition.addPermission(new perms.RevokePermission(issuerLink));

    followerContract.addFollowerSpecific();

    await followerContract.seal(true);
    await followerContract.addSignatureToSeal(issuerKeys);

    return followerContract;
}

/**
 * Add to base {@link Contract} constraint and referenced contract.
 * When the returned {@link Contract} is unpacking referenced contract verifies
 * the compliance with the conditions of constraint in base contract.
 *
 * Also constraint to base contract may be added by {@link Contract#addConstraint(Constraint)}.
 *
 * @param {Contract} baseContract - Base contract for adding constraint.
 * @param {Contract} refContract - Referenced contract (which must satisfy the conditions of the constraint).
 * @param {string} constrName - Name of constraint.
 * @param {number} constrType - Type of constraint (section, may be {@link Constraint#TYPE_TRANSACTIONAL},
 *        {@link Constraint#TYPE_EXISTING_DEFINITION}, or {@link Constraint#TYPE_EXISTING_STATE}).
 * @param {object} conditions - Conditions of the constraint.
 * @return {Contract} contract with constraint.
 */
async function addConstraintWithConditionsToContract(baseContract, refContract, constrName, constrType, conditions) {

    let constr = new Constraint(baseContract);
    constr.name = constrName;
    constr.type = constrType;

    constr.setConditions(conditions);
    constr.addMatchingItem(refContract);

    baseContract.addConstraint(constr);
    await baseContract.seal(true);

    return baseContract;
}

/**
 * Add to base {@link Contract} constraint and referenced contract.
 * When the returned {@link Contract} is unpacking referenced contract verifies
 * the compliance with the conditions of constraint in base contract.
 *
 * Also constraint to base contract may be added by {@link Contract#addConstraint(Constraint)}.
 *
 * @param {Contract} baseContract - Base contract for adding constraint.
 * @param {Contract} refContract - Referenced contract (which must satisfy the conditions of the constraint).
 * @param {string} constrName - Name of constraint.
 * @param {number} constrType - Type of constraint (section, may be {@link Constraint#TYPE_TRANSACTIONAL},
 *        {@link Constraint#TYPE_EXISTING_DEFINITION}, or {@link Constraint#TYPE_EXISTING_STATE}).
 * @param {Array<string>} listConditions - Array of strings with conditions of the constraint.
 * @param {boolean} isAllOfConditions - Flag used if all conditions in list must be fulfilled (else - any of conditions).
 * @return {Contract} contract with constraint.
 */
async function addConstraintToContract(baseContract, refContract, constrName, constrType, listConditions, isAllOfConditions) {

    let conditions = {};
    conditions[isAllOfConditions ? "all_of" : "any_of"] = listConditions;

    return await addConstraintWithConditionsToContract(baseContract, refContract, constrName, constrType, conditions);
}

/**
 * Create paid transaction, which consist from contract you want to register and payment contract that will be
 * spend to process transaction.
 *
 * @param {Contract | TransactionPack} payload - Prepared contract you want to register in the Universa.
 * @param {Contract} payment - Approved contract with "U" belongs to you.
 * @param {number} amount - Number of "U" you want to spend to register payload contract.
 * @param {Set<crypto.PrivateKey> | Array<crypto.PrivateKey>} keys - Own private keys, which are set as owner of payment contract.
 * @param {boolean} withTestPayment - If true {@link Parcel} will be created with test payment.
 * @return {Parcel} Parcel, it ready to send to the Universa.
 */
async function createParcel(payload, payment, amount, keys, withTestPayment = false) {

    let paymentDecreased = await payment.createRevision(keys);
    let payloadPack;
    if (payload instanceof Contract) {
        paymentDecreased.getTransactionalData()["id"] = payload.id.base64;

        if (payload.transactionPack == null)
            payloadPack = payload.transactionPack = new TransactionPack(payload);
        else
            payloadPack = payload.transactionPack;

    } else if (payload instanceof TransactionPack)
        payloadPack = payload;
    else
        throw new ex.IllegalArgumentError("Illegal type of payload. Expected Contract or TransactionPack.");

    if (withTestPayment)
        paymentDecreased.state.data.test_transaction_units = payment.state.data.test_transaction_units - amount;
    else
        paymentDecreased.state.data.transaction_units = payment.state.data.transaction_units - amount;

    await paymentDecreased.seal(true);

    return new Parcel(payloadPack, paymentDecreased.transactionPack);
}

/**
 * Create paid transaction, which consist from prepared TransactionPack you want to register
 * and payment contract that will be spend to process transaction.
 * Included second payment.
 * It is an extension to the parcel structure allowing include additional payment field that will not be
 * registered if the transaction will fail.
 * <br><br>
 * Creates 2 U payment blocks:
 * <ul>
 * <li><i>first</i> (this is mandatory) is transaction payment, that will always be accepted, as it is now</li>
 * <li><i>second</i> extra payment block for the same U that is accepted with the transaction inside it. </li>
 * </ul>
 * Technically it done by adding second payment to the new items of payload transaction.
 * <br><br>
 * Node processing logic logic is:
 * <ul>
 * <li>if the first payment fails, no further action is taking (no changes);</li>
 * <li>if the first payments is OK, the transaction is evaluated and the second payment should be the part of it;</li>
 * <li>if the transaction including the second payment is OK, the transaction and the second payment are registered altogether;</li>
 * <li>if any of the latest fail, the whole transaction is not accepted, e.g. the second payment is not accepted too.</li>
 * </ul>
 * <br><br>
 *
 * @param {TransactionPack} payload - Prepared TransactionPack you want to register in the Universa.
 * @param {Contract} payment - Approved contract with "U" belongs to you.
 * @param {number} amount - Number of "U" you want to spend to register payload contract.
 * @param {number} amountSecond - Number of "U" you want to spend from second payment.
 * @param {Set<crypto.PrivateKey> | Array<crypto.PrivateKey>} keys - Own private keys, which are set as owner of payment contract.
 * @param {boolean} withTestPayment - If true {@link Parcel} will be created with test payment.
 * @return {Parcel} Parcel, it ready to send to the Universa.
 */
async function createPayingParcel(payload, payment, amount, amountSecond, keys, withTestPayment = false) {

    let paymentDecreased = await payment.createRevision(keys);

    if (withTestPayment)
        paymentDecreased.state.data.test_transaction_units = payment.state.data.test_transaction_units - amount;
    else
        paymentDecreased.state.data.transaction_units = payment.state.data.transaction_units - amount;

    await paymentDecreased.seal(true);
    let paymentPack = paymentDecreased.transactionPack;

    let paymentDecreasedSecond = await paymentDecreased.createRevision(keys);

    if (withTestPayment)
        paymentDecreasedSecond.state.data.test_transaction_units = paymentDecreased.state.data.test_transaction_units - amountSecond;
    else
        paymentDecreasedSecond.state.data.transaction_units = paymentDecreased.state.data.transaction_units - amountSecond;

    await paymentDecreasedSecond.seal();

    // we add new item to the contract, so we need to recreate transaction pack
    let mainContract = payload.contract;
    mainContract.newItems.add(paymentDecreasedSecond);
    await mainContract.seal(true);
    mainContract.transactionPack.extractAllSubItemsAndReferenced(mainContract);

    return new Parcel(mainContract.transactionPack, paymentPack);
}

/**
 * Create a batch contract, which registers all the included contracts, possibily referencing each other,
 * in the single transaction, saving time and reducing U cost. Note that if any of the batched contracts
 * fails, the whole batch is rejected.
 *
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey>} keys - To sign batch with.
 * @param {...Contract} contracts - To register all in one batch. Should be prepared and sealed.
 * @return {Contract} batch contract that includes all contracts as new items.
 */
async function createBatch(keys, ...contracts) {
    let batch = new Contract();
    batch.registerRole(new roles.SimpleRole("issuer", keys));
    batch.registerRole(new roles.RoleLink("creator", "issuer"));
    batch.registerRole(new roles.RoleLink("owner", "issuer"));

    let expires = new Date();
    expires.setDate(expires.getDate() + 3);
    batch.setExpiresAt(expires);

    for (let c of contracts)
        batch.newItems.add(c);

    for (let k of keys)
        batch.keysToSignWith.add(k);

    await batch.seal(true);
    return batch;
}

/**
 * Update source contract so it can not be registered without valid Consent contract, created in this call.
 * To register the source contract therefore it is needed to sign the consent with all keys which addresses
 * are specified with the call, and register consent contract separately or in the same batch with the source contract.
 *
 * @param {Contract} source - Contract to update. Must not be registered (new root or new revision).
 * @param {...crypto.KeyAddress} consentKeyAddresses - Addresses that are required in the consent contract.
 * Consent contract should be then signed with corresponding keys.
 * @return {Contract} Consent contract.
 */
async function addConsent(source, ...consentKeyAddresses) {
    let consent = new Contract();
    consent.registerRole(new roles.SimpleRole("issuer", consentKeyAddresses));
    consent.registerRole(new roles.RoleLink("creator", "issuer"));
    consent.registerRole(new roles.RoleLink("owner", "issuer"));
    let expires = new Date();
    expires.setDate(expires.getDate() + 10);
    consent.setExpiresAt(expires);

    let ownerLink = new roles.RoleLink("@owner_link","owner");
    consent.registerRole(ownerLink);
    consent.definition.addPermission(new perms.RevokePermission(ownerLink));
    consent.definition.addPermission(new perms.ChangeOwnerPermission(ownerLink));
    consent.createTransactionalSection();
    consent.transactional.id = HashId.of(randomBytes(64)).base64;

    await consent.seal(true);

    let constr = new Constraint(source);
    constr.name = "consent_" + consent.id;
    constr.type = Constraint.TYPE_TRANSACTIONAL;
    constr.transactional_id = consent.transactional.id;
    constr.signed_by.push(consent.roles.issuer);

    if (source.transactional == null)
        source.createTransactionalSection();

    source.addConstraint(constr);

    return consent;
}

/**
 * Create escrow contracts (external and internal) for a expiration period of 5 years.
 * External escrow contract includes internal escrow contract. Contracts are linked by internal escrow contract origin.
 * To internal escrow contract establishes the owner role, {@link ListRole} on the basis of the quorum of 2 of 3 roles: customer, executor and arbitrator.
 * This role is granted exclusive permission to change the value of the status field of internal escrow contract (state.data.status).
 * Possible values for the internal escrow contract status field are: opened, completed and canceled.
 *
 * If necessary, the contents and parameters (expiration period, for example) of escrow contracts
 * can be changed before sealing and registration. If internal escrow contract has changed, need re-create external
 * escrow contract by {@link ContractsService#createExternalEscrowContract(Contract, Collection)}.
 *
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey>} issuerKeys - Issuer escrow contract private keys.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} customerKeys - Customer public keys.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} executorKeys - Executor public keys.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} arbitratorKeys - Arbitrator public keys.
 * @return {Contract} external escrow contract.
 */
async function createEscrowContract(issuerKeys, customerKeys, executorKeys, arbitratorKeys) {

    // Create internal escrow contract
    let escrow = await createInternalEscrowContract(issuerKeys, customerKeys, executorKeys, arbitratorKeys);

    // Create external escrow contract (escrow pack)
    return createExternalEscrowContract(escrow, issuerKeys);
}

/**
 * Creates internal escrow contract for a expiration period of 5 years.
 * To internal escrow contract establishes the owner role, {@link ListRole} on the basis of the quorum of 2 of 3 roles: customer, executor and arbitrator.
 * This role is granted exclusive permission to change the value of the status field of internal escrow contract (state.data.status).
 * Possible values for the internal escrow contract status field are: opened, completed and canceled.
 *
 * If necessary, the contents and parameters (expiration period, for example) of escrow contract
 * can be changed before sealing and registration. If internal escrow contract has changed, need re-create external
 * escrow contract (if used) by {@link ContractsService#createExternalEscrowContract(Contract, Collection)}.
 *
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey>} issuerKeys - Issuer escrow contract private keys.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} customerKeys - Customer public keys.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} executorKeys - Executor public keys.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} arbitratorKeys - Arbitrator public keys.
 * @return {Contract} internal escrow contract.
 */
async function createInternalEscrowContract(issuerKeys, customerKeys, executorKeys, arbitratorKeys) {

    // Create internal escrow contract
    let escrow = new Contract();
    escrow.definition.expiresAt = new Date(escrow.definition.createdAt);
    escrow.definition.expiresAt.setMonth(escrow.definition.expiresAt.getMonth() + 60);
    escrow.state.data.status = "opened";

    escrow.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    escrow.registerRole(new roles.RoleLink("creator", "issuer"));

    // quorum role
    let quorumOwner = new roles.ListRole("owner", [
        new roles.SimpleRole("customer", customerKeys),
        new roles.SimpleRole("executor", executorKeys),
        new roles.SimpleRole("arbitrator", arbitratorKeys)
    ], roles.ListRoleMode.QUORUM, 2);

    escrow.registerRole(quorumOwner);

    let ownerLink = new roles.RoleLink("@owner_link", "owner");
    ownerLink.contract = escrow;

    // modify permission
    escrow.definition.addPermission(new perms.ModifyDataPermission(ownerLink, {fields : {status : ["completed", "canceled"]}}));

    // constraint for deny re-complete and re-cancel
    let finalizeConstr = new Constraint(escrow);
    finalizeConstr.name = "deny_re-complete_and_re-cancel";
    finalizeConstr.type =  Constraint.TYPE_EXISTING_DEFINITION;

    let conditions = {any_of : [
        "this.state.parent undefined",
        {all_of : [
            "ref.id == this.state.parent",
            "ref.state.data.status != \"completed\"",
            "ref.state.data.status != \"canceled\""
        ]}
    ]};

    finalizeConstr.setConditions(conditions);
    escrow.addConstraint(finalizeConstr);

    for (let k of issuerKeys)
        escrow.keysToSignWith.add(k);

    await escrow.seal(true);

    return escrow;
}

/**
 * Creates external escrow contract for a expiration period of 5 years.
 * External escrow contract includes internal escrow contract. Contracts are linked by internal escrow contract origin.
 *
 * If necessary, the contents and parameters (expiration period, for example) of escrow contracts
 * can be changed before sealing and registration. If internal escrow contract has changed, need re-create external
 * escrow contract by {@link ContractsService#createExternalEscrowContract(Contract, Collection)}.
 *
 * @param {Contract} internalEscrow - Internal escrow contract.
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey>} issuerKeys - Issuer escrow contract private keys.
 * @return {Contract} external escrow contract.
 */
async function createExternalEscrowContract(internalEscrow, issuerKeys) {

    // Create external escrow contract (escrow pack)
    let escrowPack = new Contract();
    escrowPack.definition.expiresAt = new Date(escrowPack.definition.createdAt);
    escrowPack.definition.expiresAt.setMonth(escrowPack.definition.expiresAt.getMonth() + 60);
    escrowPack.definition.data.EscrowOrigin = internalEscrow.getOrigin().base64;

    escrowPack.registerRole(new roles.SimpleRole("issuer", issuerKeys));
    escrowPack.registerRole(new roles.RoleLink("owner", "issuer"));
    escrowPack.registerRole(new roles.RoleLink("creator", "issuer"));

    escrowPack.newItems.add(internalEscrow);

    for (let k of issuerKeys)
        escrowPack.keysToSignWith.add(k);

    await escrowPack.seal(true);

    return escrowPack;
}

/**
 * Modifies payment contract by making ready for escrow.
 * To payment contract is added {@link Transactional} section with 2 constraints: send_payment_to_executor, return_payment_to_customer.
 * The owner of payment contract is set to {@link ListRole} contains customer role with return_payment_to_customer constraint
 * and executor role with send_payment_to_executor constraint. Any of these roles is sufficient to own a payment contract.
 *
 * @param {Contract | string} escrow - Internal escrow contract to use with payment (or his origin in base64).
 * Must be returned from {@link createInternalEscrowContract}.
 * @param {Contract} payment - Payment contract to update. Must not be registered (new root or new revision).
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey> | null} paymentOwnerKeys - Keys required for use payment contract
 * (usually, owner private keys). May be null, if payment will be signed later.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} customerKeys - Customer public keys of escrow contract.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} executorKeys - Executor public keys of escrow contract.
 * @return {Contract} payment contract ready for escrow.
 */
async function modifyPaymentForEscrowContract(escrow, payment, paymentOwnerKeys, customerKeys, executorKeys) {

    let escrowOrigin;
    if (escrow instanceof Contract)
        escrowOrigin = escrow.getOrigin().base64;
    else
        escrowOrigin = escrow;

    // Build payment contracts owner role
    let customerConstr = new Constraint(payment);
    customerConstr.name = "return_payment_to_customer";
    customerConstr.type =  Constraint.TYPE_TRANSACTIONAL;
    customerConstr.setConditions({all_of : [
        "ref.origin == " + "\"" + escrowOrigin + "\"",
        "ref.state.data.status == \"canceled\""
    ]});

    let executorConstr = new Constraint(payment);
    executorConstr.name = "send_payment_to_executor";
    executorConstr.type =  Constraint.TYPE_TRANSACTIONAL;
    executorConstr.setConditions({all_of : [
        "ref.origin == " + "\"" + escrowOrigin + "\"",
        "ref.state.data.status == \"completed\""
    ]});

    let customer = new roles.SimpleRole("customer", customerKeys);
    customer.requiredAllConstraints.add(customerConstr);
    let executor = new roles.SimpleRole("executor", executorKeys);
    executor.requiredAllConstraints.add(executorConstr);

    payment.createTransactionalSection();
    payment.transactional.id = HashId.HashId.of(randomBytes(64)).base64;

    payment.addConstraint(customerConstr);
    payment.addConstraint(executorConstr);

    let paymentOwner = new roles.ListRole("owner", [customer, executor], roles.ListRoleMode.ANY);

    // Modify payment contract
    payment.registerRole(paymentOwner);

    if (paymentOwnerKeys != null)
        for (let k of paymentOwnerKeys)
            payment.keysToSignWith.add(k);

    await payment.seal();

    return payment;
}

/**
 * Checks external escrow contract and add payment contract to it.
 * To payment contract is added {@link Transactional} section with 2 constraints: send_payment_to_executor, return_payment_to_customer.
 * The owner of payment contract is set to {@link ListRole} contains customer role with return_payment_to_customer constraint
 * and executor role with send_payment_to_executor constraint. Any of these roles is sufficient to own a payment contract.
 *
 * @param {Contract} escrow - Escrow contract (external) to use with payment. Must be returned from {@link createEscrowContract}.
 * @param {Contract} payment - Payment contract to update. Must not be registered (new root or new revision).
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey> | null} paymentOwnerKeys - Keys required for use payment contract
 * (usually, owner private keys). May be null, if payment will be signed later.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} customerKeys - Customer public keys of escrow contract.
 * @param {Array<crypto.PublicKey> | Set<crypto.PublicKey>} executorKeys - Executor public keys of escrow contract.
 * @return {boolean} result of checking external escrow contract and adding payment to it.
 */
async function addPaymentToEscrowContract(escrow, payment, paymentOwnerKeys, customerKeys, executorKeys) {

    // Check external escrow contract
    let escrowOrigin = escrow.definition.data.EscrowOrigin;
    if (escrowOrigin == null)
        return false;

    if (!Array.from(escrow.newItems).some(c => c.getOrigin().base64 === escrowOrigin && c.state.data.status === "opened"))
        return false;

    payment = await modifyPaymentForEscrowContract(escrowOrigin, payment, paymentOwnerKeys, customerKeys, executorKeys);

    // Add payment contract to external escrow
    escrow.newItems.add(payment);
    await escrow.seal(true);

    return true;
}

/**
 * Completes escrow contract. All linked payments are made available to the executor.
 * For registration completed escrow contract require quorum of 2 of 3 roles: customer, executor and arbitrator.
 *
 * @param {Contract} escrow - Escrow contract (external or internal) to complete. Must be registered for creation new revision.
 * @return {Contract} completed internal escrow contract or null if error occurred.
 */
async function completeEscrowContract(escrow) {

    let escrowInside = escrow;

    if (escrow.state.data.status !== "opened") {      // external escrow contract (escrow pack)
        // Find internal escrow contract in external escrow contract (escrow pack)
        let escrowOrigin = escrow.definition.data.EscrowOrigin;
        if (escrowOrigin == null)
            return null;

        escrowInside = null;
        for (let c of escrow.newItems)
            if (c.getOrigin().base64 === escrowOrigin && c.state.data.status === "opened") {
                escrowInside = c;
                break;
            }

        if (escrowInside == null)
            return null;
    }

    let revisionEscrow = await escrowInside.createRevision();
    revisionEscrow.state.data.status = "completed";
    await revisionEscrow.seal(true);

    return revisionEscrow;
}

/**
 * Cancels escrow contract. All linked payments are made available to the customer.
 * For registration canceled escrow contract require quorum of 2 of 3 roles: customer, executor and arbitrator.
 *
 * @param {Contract} escrow - Escrow contract (external or internal) to cancel. Must be registered for creation new revision.
 * @return {Contract} canceled internal escrow contract or null if error occurred.
 */
async function cancelEscrowContract(escrow) {

    let escrowInside = escrow;

    if (escrow.state.data.status !== "opened") {      // external escrow contract (escrow pack)
        // Find internal escrow contract in external escrow contract (escrow pack)
        let escrowOrigin = escrow.definition.data.EscrowOrigin;
        if (escrowOrigin == null)
            return null;

        escrowInside = null;
        for (let c of escrow.newItems)
            if (c.getOrigin().base64 === escrowOrigin && c.state.data.status === "opened") {
                escrowInside = c;
                break;
            }

        if (escrowInside == null)
            return null;
    }

    let revisionEscrow = await escrowInside.createRevision();
    revisionEscrow.state.data.status = "canceled";
    await revisionEscrow.seal(true);

    return revisionEscrow;
}

/**
 * Transfers payment contract to new owner on the result of escrow.
 * Use payment contract that was added to external escrow contract by
 * {@link addPaymentToEscrowContract} or was modified by {@link modifyPaymentForEscrowContract}.
 * Executor can take the payment contract, if internal escrow contract are completed.
 * Customer can take the payment contract, if internal escrow contract are canceled.
 * For registration payment contract (returned by this method) need to add result internal escrow contract to
 * {@link TransactionPack#referencedItems}.
 *
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey>} newOwnerKeys - Private keys of new owner of payment.
 * @param {Contract} payment - Payment contract to take by new owner. Must be registered for creation new revision.
 * @return {Contract} new revision of payment contract with new owner.
 */
async function takeEscrowPayment(newOwnerKeys, payment) {
    let revisionPayment = await payment.createRevision(newOwnerKeys);

    // set new owner
    revisionPayment.registerRole(new roles.SimpleRole("owner", newOwnerKeys));

    // remove escrow constraints from Contract.constraints (from transactional section constraints removed automatically)
    revisionPayment.constraints.delete("return_payment_to_customer");
    revisionPayment.constraints.delete("send_payment_to_executor");
    await revisionPayment.seal(true);

    return revisionPayment;
}

/**
 * Creates special contract to set unlimited requests for the {@link PublicKey}.
 * The base limit is 30 per minute (excludes registration requests).
 * Unlimited requests for 5 minutes cost 5 U.
 * Register result contract.
 *
 * @param {crypto.PublicKey} key - Key for setting unlimited requests.
 * @param {Contract} payment - Approved contract with "U" belongs to you.
 * @param {number} amount - Number of "U" you want to spend to set unlimited requests for key; get by {@link Config#getRateLimitDisablingPayment()}.
 * @param {Array<crypto.PrivateKey> | Set<crypto.PrivateKey>} keys - Own private keys, which are set as owner of payment contract.
 * @return {Contract} contract for setting unlimited requests to key.
 */
async function createRateLimitDisablingContract(key, payment, amount, keys) {

    let unlimitContract = await payment.createRevision(keys);

    unlimitContract.createTransactionalSection();
    unlimitContract.transactional.id = HashId.of(randomBytes(64)).base64;
    unlimitContract.transactional.data.unlimited_key = key.packed;

    unlimitContract.state.data.transaction_units = payment.state.data.transaction_units - amount;
    await unlimitContract.seal(true);

    return unlimitContract;
}

module.exports = {createRevocation, createSplit, createJoin, createSplitJoin, startSwap, createTwoSignedContract,
    createTokenContract, createMintableTokenContract, createShareContract, createNotaryContract, checkAttachNotaryContract,
    createSlotContract, createUnsContract, createUnsContractForRegisterContractName, createUnsContractForRegisterKeyName,
    createFollowerContract, addConstraintWithConditionsToContract, addConstraintToContract, createParcel, createPayingParcel,
    createBatch, addConsent, createEscrowContract, createInternalEscrowContract, createExternalEscrowContract,
    modifyPaymentForEscrowContract, addPaymentToEscrowContract, completeEscrowContract, cancelEscrowContract,
    takeEscrowPayment, createRateLimitDisablingContract};
