/*
 * Copyright (c) 2019-present Sergey Chernov, iCodici S.n.C, All Rights Reserved.
 */
// unsafe
// eee.dsds = 11

// require = function() { throw "security error 1";}
// this.require = function() { throw "security error 2";}
console.log("Simulate exiting the scope", this);
// console.log("m = " + Object.keys(modules));
// moodules = undefined
// console.log(Object.keys(modules['timers.js']));
// modules['timers.js'] = {}
// modules['lala.js'] = { exports: []}

