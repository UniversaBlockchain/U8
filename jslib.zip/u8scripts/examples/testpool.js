/*
 * Copyright (c) 2019-present Sergey Chernov, iCodici S.n.C, All Rights Reserved.
 */

async function main(args) {
    const factor = 4;
    console.log(`parallelism factor: ${platform.hardwareConcurrency}`)
    return 0;
}